package com.mycompany.loggerdemo;

public class ConsoleLogger extends BaseLogger {
	public ConsoleLogger() {
		label = "Console logger";
	}
 
	public String getLevel() {
		return "info";
	}
}

