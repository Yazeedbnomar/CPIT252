package edu.kau.fcit.cpit252;
public interface WeatherCity {
    public String getWeatherInfo(String city);
    
}
